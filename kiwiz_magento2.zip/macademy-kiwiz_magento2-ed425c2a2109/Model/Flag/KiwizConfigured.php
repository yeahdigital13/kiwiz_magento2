<?php

namespace Kwz\Certification\Model\Flag;

use Magento\Framework\Flag;

class KiwizConfigured extends Flag
{
    protected $_flagCode = 'kiwiz_first_configuration';
}
