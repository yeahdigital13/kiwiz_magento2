<?php

namespace Kwz\Certification\Block\Adminhtml\Order\View\Invoice;



use Magento\Sales\Block\Adminhtml\Order\View\Info;

class Status extends \Magento\Sales\Block\Adminhtml\Order\View\Info
{

}